-- AlterTable
ALTER TABLE "User" ADD COLUMN "lastPackAt" DATETIME;
